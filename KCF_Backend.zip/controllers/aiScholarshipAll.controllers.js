



const aiScholarshipAll = async(req,res) => {
   console.log("aiScholarship reached!")
}





export default aiScholarshipAll;